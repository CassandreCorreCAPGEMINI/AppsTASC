#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   tasc.py
@Time    :   2023/10/13 10:18:17
@Author  :   Xin HUANG 
@Version :   1.0
@Contact :   xin.huang@capgemini.com
'''

# here put the import lib

import streamlit as st
from streamlit.logger import get_logger

LOGGER = get_logger(__name__)


def run():
    st.set_page_config(page_title="TASC Weolcome page",page_icon="random",layout="wide")
    st.image("TASC-orange-horizontal-logo.png",width=500)

    st.write("# Welcome to Project TASC! ")

    st.sidebar.success("Select an app above.")

    st.markdown(
        """
       
        ** 👈 Select an app from the sidebar** to see some examples
      
        ### ​​Objectifs
        - Digital Maturity Evaluation
        - CSR Maturity Evaluation
        - Generative AI for Contract Management
    """
    )


if __name__ == "__main__":
    run()
