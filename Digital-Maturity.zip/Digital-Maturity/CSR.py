#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   app1.py
@Time    :   2023/09/28 11:07:57
@Author  :   Xin HUANG 
@Version :   1.0
@Contact :   xin.huang@capgemini.com
'''

# here put the import lib



import streamlit as st
import random
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import gspread

import os
import sys

st.set_page_config(page_title="TASC Welcome page",page_icon="random",layout="wide")

st.header("Évaluation de la RSE")
e1 = st.text_input('Nom de l\'entreprise')
e2 = st.text_input('Adresse mail')
e3 = st.text_input('Rôle du participant')
e4 = st.text_input('Taille de l\'entreprise')
e5 = st.text_input('Secteur d\'activité')
e = e1+e2+e3+e4+e5

qs = ["Does the company provide an annual CSR report ? ",
      "Does the company integrate CSR notions into its global strategy and has a responsible for its CSR policy ?",
     " Does the person in charge of CSR have sufficient material and human resources ?",
     "Does the company's operational decision-making process integrate the measurement and study of CSR risks and opportunities?",
     "Does the company make its employees aware of CSR issues.",
     "Does the company communicate its CSR performance to all its stakeholders?",
     "Is there a system for handling/controlling Legal CSR requirements, how is the company informed about new legislation?",
     "Does the company have a non-discrimination policy in place?",
     "Is the company performing its duty of vigilance regarding its external stakeholders?",
     "Does the company have a certified and globally recognized health and safety management system?",
     "Does the company promote and maintain the importance of safety and physical, mental and social well-being of workers to the highest degree?",
     "Does the company provide employees with a career path based on principles of equity and non-discrimination, taking into account their state of health?",
     "Does the company have a code of conduct in place?",
     "Does the company ensure decent working conditions, taking into account the specificities of the geographical areas (cost of living, etc.)?",
     "Do the working conditions of the employees of the company's suppliers meet the requirements set by the company for its employees?",
     "Does the company ensure its contribution to good standard of living of its employee by guaranting job stability and decent work?",
     "Does the company ensure employees' awareness of their rights, responsibilities, and legal action?",
     "Does the company protect employees' personal data and privacy based on the local laws?",
     "Does the company have a policy on freedom of worker association and collective bargaining?",
     "Does the company involve employees in the discussions that lead to decisions?",
     "Does the company have a transparent and fair compensation policy?",
     "Does the company provide an effective social protection system?",
     "Does the company share with its employees the information needed to protect their health and safety?",
     "Is the company able to measure the impact of its activities in terms of pollution?",
     "Is the company able to accurately measure its direct GHG emissions? (scope 1)",
     "Is the company able to accurately measure its GHG emissions derived from its energy consumption? (scope 2)",
     "Is the company able to measure the GHG emissions derived from the whole supply chain ? (scope 3). ",
     "Has the company identified potential circular economy loops within its operations?",
     "Are training sessions organized to increase employees' understanding about circular economy?",
     "Is the company performing LCA of their products and/or services?",
     "Has the company trained its buyers in sustainable purchasing?",
     "Has the company mapped its impacts on biodiversity?",
     "Does the company integrate the notion of biodiversity in its development projects?",
     "Is the company in a process of sustainable relations with its suppliers?",
     "Has the company conducted a dependency analysis of its customers and suppliers/subcontractors?",
     "Has the company conducted training sessions for its buyers to make them aware of the risks of too much pressure on prices and the advantages of creating win/win partnerships/relationships with its suppliers?",
     "Does the company provide training to the employees likely to be exposed to corruption risks?",
     "Does the company have a transparant anti-corruption, gift/benefits policy?",
     "Does the company regularly conduct a corruption risk assessment?",
     "Is the staff being trained about the risk of unfair competition?",
     "Does the company conduct a regular assessment of fair competition practices?",
     "Does the company train its employees in purchasing and fair marketing?",
     "Does the company make its production / sourcing 100% transparent to all its stakeholders and in particular to its end customers? ",
     "Has the company clearly defined its commitments in terms of quality / safety towards its consumers?",
     "Does the company have tools or a process to ensure the traceability of its products / operations and actions?",
     "Does the company have a specific access point for customer feedback? Is this access point known to all the stakeholders? ",
     "Does the company have a clear return policy? (deadlines, processing methods, return conditions, etc.)",
     "Does the company evaluate the quality level of its after-sales service? ",
     "Does the company clearly inform its customers/consumers about how their data will be collected, managed and stored?",
     "Does the company educate its employees on data protection methods?",
     "Is the company involved in the community life of its locality? Does it contribute to improve their economic and social conditions?",
     "Has the company defined budget for its common good actions? ",
     "Does the company have relationships with the local employment partners?",
     "Does the company have a clear and shared policy in terms of public health and safety?",
     "Does the company know the risks of its activity on local populations' health?",
     "Does the company provide adequate training to its employees on the potential risks that may arise and on how to protect the surrounding populatio"
]

options_list = list()
options_list.append(["1 - No annual CSR report provided (neither data nor content)","2 - Some CSR informations are provided internally with data & content","3 - A partially internally report is provided with data & content  (example : only environmental topics) ","4 - A complete internally report is provided with data & content","5 - A public CSR report is published with quality criteria aligned with the international norms","N/A"])
options_list.append(["1 - No one responsible for CSR","2 - A person partially in charge of CSR","3 - A person dedicated to CSR but not in a strategic function","4 - A person dedicated to CSR  with a strategic function","5 - CEO in charge of CSR ","N/A"])
options_list.append(["1 - No material and human ressources dedicaded","2 - Material and/or Human ressources available to manage CSR topics","3 - Material and Human ressources dedicated","4 - Material & human ressources fully dedicated to CSR. Each year a significant part of the budget is dedicad to CSR stakes","5 - Material & human ressources fully dedicated to CSR. Budget increase 3 years in a row","N/A"])
options_list.append(["1 - The company's operational decision-making process does not integrate the measurement and study of CSR risks and opportunities.","2 - The company uses some key CSR indicators in its activities (SMART) without decision making process associated. (pas quantifié) juste qualitatif","3 - The company makes some decisions with the notion of CSR. The company uses some key CSR indicators in its activities (SMART) quantifié","4 - The company partially integrates the notion of CSR into its decision-making process with monitored key performance indicators (operationnal level) on fait un suivi et contrôle","5 - The company fully integrates the notion of CSR into its decision-making process with monitored key performance indicators with  actions plan (continuous improvement)","N/A"])
options_list.append(["1 - No training done","2 - Training done only for some employees","3 - All employees trained during their on boarding period","4 - Systematic trainings every 3 years to update all sales team","5 - Training done for each changes of the reglementations or internal procedures","N/A"])
options_list.append(["1 - No communication","2 - The company communicates internally on some CSR indicators (example : only environmental topics)","3 - The company communicates internally (only with manager) on some CSR indicators. Setting up a discussion in terms of CSR expectations ","4 - Internally and externally reported CSR performance in line with stakeholders' expectations","5 - Collaboration with the different stakeholders for the different expectations (customer, supplier ...)","N/A"])
options_list.append(["1 - Cannot clearly demonstrate whether regulatory requirements are met.","2 - Awareness on all regulations and adherence can be demonstrated. Planning to have a process to ensure continuous accordance with the legislation.","3 - Systematic processes in place to ensure all regulations are adhered to.","4 - High developed processes in order to follow the regulations and to monitor suppliers on their level.","5 - Separate Legal team is available with regular monitoring of legislation and ensure it is deployed to the whole organization and stakeholders.","N/A"])
options_list.append(["1 - No non-discrimination policy in place in the company","2 - An internal regulation dealing with some non-discrimination issues","3 - An internal regulation with a special chapter about non-discrimination. Internal communication","4 - A clear and defined policy on non-discrimination has been put in place with an awareness-raising campaign for all employees","5 - A clear and defined policy on non-discrimination has been put in place, with all employees made aware of it through awareness, external communication and on-going monitoring (contrôle externe via un orgnisme spécialisé)","N/A"])
options_list.append(["1 - No supplier & subcontractor policy put in place","2 - No particular vigilance towards suppliers and subcontractors","3 - The company ensures the CSR policy of its suppliers and subcontractors (only tier 1). Policy","4 - The company ensures the CSR policy of its suppliers and subcontractors. Tier 1 to Tier ... …(document audit)","5 - The company ensures the CSR policy of its suppliers and subcontractors. Tier 1 to Tier … (on site audit)","N/A"])
options_list.append(["1 - The company has no health and safety management system","2 - The company has a system for identifying and assessing health and safety risks. Use and update the single document to meet the regulatory obligation","3 - Managing the prevention programme to reduce risks","4 - Incidents are followed up by documented  corrective and preventive actions. Safety cultute promoted.","5 - Apply the ISO 45001 standard on occupational health and safety management systems","N/A"])
options_list.append(["1 - The company implements the legal minimum on the importance of the safety and physical, mental and social well-being of workers","2 - The company provides training for some managers on the importance of safety and the physical, mental and social well-being of workers","3 - The company communicates on the subject and sets up mandatory  training for managers and some employees on the importance of safety and the physical, mental and social well-being of workers","4 - The company communicates on the subject on a regular basis and provides mandatory training for managers and all employees on the importance of safety and the physical, mental and social well-being of workers","5 - The company communicates regularly on the subject internally and externally and provides compulsory training for all employees on the importance of safety and the physical, mental and social well-being of workers. All training content is updated very regularly with active monitoring","N/A"])
options_list.append(["1 - The company has not set up career paths within its processes. Nor does it have a specific policy on non-discrimination and their state of health.","2 - The company has set up job descriptions with associated skills. Training courses are proposed by the company","3 - The company offers a career path with competence management. It promotes internal and external training. Its career path is adapted and a non-discrimination policy is in place.","4 - The company has a significant budget for employee career development and training via a platform accessible on the intranet. It also communicates actively on its non-discrimination policy and on the implementation of all actions to promote work in the disabled sector","5 - Budget increase 3 years in a row for employee career development and training via a platform accessible on the intranet (Internal university). It also communicates actively on its non-discrimination policy and on the implementation of all actions to promote work in the disabled sector","N/A"])
options_list.append(["1 - The company has no code of conduct or harassment policy","2 - An internal regulation dealing with some harassment topics","3 - An internal regulation with a special chapter about harassment. Internal communication","4 - A clear and defined code of conduct has been put in place with an awareness-raising campaign for all employees with a special training harassment","5 - A clear and defined policy on non-discrimination has been put in place, with all employees made aware of it through awareness, external communication and on-going monitoring","N/A"])
options_list.append(["1 - The company provides the legal minimum for its employees (salary & advantages policy)","2 - The company has put in place some benefits in addition to the legal minimum  (salary & advantages policy)","3 - The company has introduced benefits in addition to the legal minimum in consultation with employee representatives  (salary & advantages policy)","4 - The company has put in place a clear salary & advantages policy in agreement with staff representatives based on several criteria.","5 - The company has put in place a policy in agreement with staff representatives based on several criteria including 'the cost of living by geographical area","N/A"])
options_list.append(["1 - No internal approach and policy on suppliers' working conditions","2 - A prevention plan is signed by both parties.","3 - A prevention plan is signed by both parties. The necessary work and safety equipment is provided for the supplier","4 - A prevention plan is signed by both parties. The necessary work and safety equipment is provided for the supplier a presentation of the site and the security systems is given on the supplier's first day of work","5 - A prevention plan is signed by both parties. The necessary work and safety equipment is provided for the suppliera presentation of the site and the security systems is given on the supplier's first day of work a dedicated space for suppliers is set up within the company","N/A"])
options_list.append(["1 - The company complies with local legislation & by sector on remuneration and decent  work","2 - The company offers permanent employment contracts for the most part. Salary increases are decided on a case-by-case basis (performance)","3 - The company offers permanent employment contracts for all of the employes. A budget for wage increases is planned for all employees (company & individual performance)","4 - The company offers permanent employment contracts for all of the employes. A budget for wage increases is planned for all employees in line with inflation. A general salary increase is also put in place.","5 - The company offers permanent employment contracts for all of the employes. A budget for wage increases is planned for all employees in line with inflation. A general salary increase is also put in place. A redistribution of profits to employees is put in place as a bonus form","N/A"])
options_list.append(["1 - No information is put in place by the company for employees on their rights, responsibilities","2 - Mandatory posting (physical and intranet)","3 - Regular information and reminder campaign to all employees","4 - Mandatory awareness campaign for all employees with sign-up sheets","5 - The company implements a policy of full transparency on rights, responsibilities and legal action of its employees","N/A"])
options_list.append(["1 - The company has not implemented any specific protection of personal and private data","2 - The company does not have a robust personal data policy in terms of collection, storage, access, rectification, opposition, deletion.","3 - The company has clear rules according to the robust personal data regulation in terms of collection, storage, access, rectification, opposition, deletion.","4 - the company sets up awareness and information sessions on the protection of personal data","5 - The company has a transparent policy on personal data management with internal and external communication. The company also has a person in charge of this subject","N/A"])
options_list.append(["1 - The company has no policy on freedom of association and collective bargaining","2 - The company does not encourage the establishment of worker associations. There is no collective bargaining","3 - The company leaves the setting up of worker associations free. Discussions and negotiations are held on a regular basis","4 - Workers' associations are included in discussions and negotiations on all company topics","5 - Workers' associations are involved in all discussions and negotiations on all company issues. They are involved in all decisions","N/A"])
options_list.append(["1 - There is no social dialogue in the company. Decisions are taken directly by the company's management","2 - Employees are sometimes consulted in company decisions","3 - Employees are partially consulted & involved in company decisions","4 - Employees are consulted and involved in company decisions","5 - No decision is taken in the company without the consultation and involvement of the employees with real representation","N/A"])
options_list.append(["1 - The compensation policy of the company is limited to the mandatory / legal requirements for all employees.","2 - A given percentage of transportation charges are covered by the compensation policy according to function level of the employees.","3 - A given percentage of transportation and housing subsidies are covered by the compensation policy according to function level of the employees.","4 - 100% of transportation and a housing subsidy are covered by the compensation policy. Equally for all employees.","5 - sport, culture and enterteinment subsidies are included in the compensation policy, equally for all employees and extended to their families.","N/A"])
options_list.append(["1 - The social protection system of the company is limited to the mandatory / legal requirements.","2 - The company has introduced some benefits in addition to the legal minimum required.","3 - The company has introduced benefits in addition to the legal minimum required in consultation with employee representatives.","4 - The company has an integral social protection system (100% health coverture).","5 - The company has an integral social protection system (100% health coverture), including family relatives.","N/A"])
options_list.append(["1 - No Health & Safety metrics are in place",",2 - Health & Safety metrics are regularly monitored & followed only by HR","3 - Health & Safety metrics are regularly monitored & shown at company's entries","4 - Health & Safety metrics are regularly monitored & shown at company's entries with actions plan for improvement","5 - Health & Safety metrics are regularly monitored & shown at company's entries demonstrating 3 continuous years of improvement","N/A"])
options_list.append(["1 - Any action regarding pollution impacts.","2 - The company has specifically identified the elements of its activities that pollute.","3 - The company quantifies and controls its impact in terms of pollution.","4 - The company has set a target and an action plan to reduce its impact in terms of pollution.","5 - The targets concerning the reduction of pollution are visible and displayed throughout the company, and there are improvements in the target for the last three years.","N/A"])
options_list.append(["1 - Any action regarding direct GHG emissions.","2 - The direct GHG emissions are measured only for the core activity of the company. Only fixed emission sources (machines) are considered (poste 1).","3 - The direct GHG emissions are measured only for the core activity of the company. Fixed (machines) and mobile (vehicles) emission sources are considered (poste 1 et 2).","4 - The direct GHG emissions are measured for all the activities of the company. Fixed, mobile, fugitive and biomass-related emission sources are considered (postes 1 to 5).","5 - The company has defined a target and an action plan to reduce its direct GHG emissions.","N/A"])
options_list.append(["1 - Any action regarding indirect GHG emissions of the scope 2.","2 - The indirect GHG emissions linked to energy consumption are measured only for the core activity of the company. The measurement is based on the electric mix approach (electricity emission factor at the consumer level).","3 - The indirect GHG emissions linked to energy consumption are measured for all the activities of the company. The measurement is based on the electric mix approach (electricity emission factor at the consumer level).","4 - The indirect GHG emissions linked to energy consumption are measured for all the activities of the company. The measurement considers a  lifecycle approach of the electricity (electricity emission factor at production and consumer level).","5 - The company has defined a target and an action plan to reduce its indirect GHG emissions linked to energy consumption.","N/A"])
options_list.append(["1 - Any action regarding indirect GHG emissions of the scope 3.","2 - Only the indirect emissions linked to the transport of employees, visiting customers, and shareholders are measured (business trips, home-work travels…).","3 - Indirect emissions issued from the transport of goods (in-bound and out-bound) are measured.","4 - Indirect emissions issued from the entire lifecycle of goods and services are measured (includes purchased products' manifacturing, transport, use, return, waste management).","5 - The company has defined a target and an action plan to reduce its indirect GHG emissions linked to the entire supply chain.","N/A"])
options_list.append(["1 - Any action regarding circular economy strategies (not even recycling).","2 - Recycling actions regarding packaging and other waste coming from non-production activities. ","","","","N/A"])
options_list.append(["1 - No training done.","2 - Training done only for some employees.","3 - All employees trained during their on boarding period.","4 - Systematic trainings every 3 years to update all teams.","5 - Training done for each changes of the reglementations or internal procedures.","N/A"])
options_list.append(["1 - No LCA done.","2 - LCA performed only for the core product / service of the company. Only carbon footprint is considered in the assessment.","3 - LCA performed for the core product / service of the company. Several impacts categories are considered in the assessment.","4 - LCA performed for all products / services of the company. Several impacts categories are considered in the assessment.","5 - LCA is broadly implemented as a monitoring and decision making tool througout all the company's activities. ","N/A"])
options_list.append(["1 - No training done.","2 - Training done only for purchasing managers.","3 - All buyers trained during their on boarding period.","4 - Systematic trainings every 3 years to update all purchasing teams.","5 - Training done for each changes of the reglementations or internal procedures.","N/A"])
options_list.append(["1 - Any action regarding the impacts on biodiversity.","2 - The company has specifically identified the elements of its direct activities that impact biodiversity.","3 - The company quantifies and controls the impacts of its direct activities on biodiversity.","4 - The company quantifies and controls its impact on biodiversity considering a lifecycle approach.","5 - The company has set a target and an action plan to reduce its impacts on biodiversity considering a lifecycle approach.","N/A"])
options_list.append(["1 - The notion of biodiversity is not considered.","2 - Biodiversity impacts are adressed at the development phase of projects, seeking for mitigation strategies.","3 - Biodiversity impacts are considered in the risk analysis of some projects before launching them.","4 - Biodiversity impacts are considered in the risk analysis of all projects before launching them.","5 - Biodiversity protection is part of the company's business model. ","N/A"])
options_list.append(["1 - Contract with suppliers setup only on minimum legal requirement in place","2 - Long term contrat setup only with strategic suppliers","3 - Regular review of the contractual relationship based on fair discussion","4 - Regular review of the contractual relationship based on fair discussion with clear guidline to negotiate around shared CSR criteria","5 - Shared research and innovation work with suppliers in order to bring them towards a CSR practice together ","N/A"])
options_list.append(["1 - No analysis done","2 - Partial mapping is done on forecasted key suppliers and / or clients","3 - Full mapping of the clients & suppliers is performed with ratio done based on the spending / incomes","4 - No client and / or suppliers is representing more than 25% of the spending / incomes","5 - Regular review done to not have up to 15% dependency","N/A"])
options_list.append(["1 - No training done","2 - Training done only for some accounts","3 - All buyers are trained during their on boarding process","4 - Systematic trainings every 3 years to update all sales team","4 - Systematic trainings every 3 years to update all sales team","N/A"])
options_list.append(["1 - No training done","2 - Mandatory training only for employees interacting with suppliers","3 - All employees dealing with suppliers and clients are trained","4 - All employees trained during on board period","5 - All employees trained & system in place to anonymously denounce a case of corruption in the company?","N/A"])
options_list.append(["1 - No anti corruption is in place","2 - Anti corruption policy is in place","3 - Anti corruption policy setup, employees trained and documents available on company network","4 - Anti corruption policy setup, employees trained and documents available on company website","5 - Anti corruption policy setup, employees trained and documents available on company website regular updated","N/A"])
options_list.append(["1 - No assessment done","2 - Assessment done after risks detection","3 - Assessment done in regard of Quality processes (e.g. ISO 9001)","4 - All projects audited yearly","5 - All projects audited yearly by external auditors","N/A"])
options_list.append(["1 - No training done","2 - Mandatory training only for employees interacting with suppliers","3 - All employees dealing with suppliers and clients are trained","4 - All employees trained during on board period","5 - All employees trained & system in place to anonymously denounce a case of unfair competitions in the company?","N/A"])
options_list.append(["1 - No assessment done","2 - Assessment done after risks detection","3 - Assessment done in regard of Quality processes (e.g. ISO 9001)","4 - All projects audited yearly","5 - All projects audited yearly by external auditors","N/A"])
options_list.append(["1 - No training done","2 - Mandatory training only for employees interacting with suppliers","3 - All employees dealing with suppliers and clients are trained","4 - All employees trained during on board period","5 - All employees trained & system in place to anonymously denounce a case of unfair competitions in the company?","N/A"])
options_list.append(["1 - Full Information only known by Steer Co & company board","2 - Full Information only known by supply & manufacturing departments","3 - All suppliers & internal manufacturing premises are available for all employees","4 - All suppliers & internal manufacturing premises are available on company website","5 - All suppliers & internal manufacturing premises are indicated on the product (physically)","N/A"])
options_list.append(["1 - No KPI in place","2 - Clients' KPI (quality & safety) are known only by quality & sales department","3 - Clients' KPI (quality & safety) are shared on internal network and available for all employees","4 - Clients' KPI (quality & safety) are shared on company website","5 - Clients' KPI (quality & safety) are shared on company website and audited by 3rd party","N/A"])
options_list.append(["1 - No traceability in place","2 - Partial traceability in place and manually performed in case of issues","3 - Traceability (front & back) in place and recorded by Quality department","4 - Serial Number in place with robust (front / back) traceability confirmed","5 - Serial Number in place with robust (front / back) traceability confirmed with real time access for the clients","N/A"])
options_list.append(["1 - No client's satisfaction done","2 - Client's satisfaction is done when requested by quality or after specific event(s) (e.g. client's claim)","3 - Client's satisfaction is performed at regular periods","4 - Client's satisfaction is performed at regular periods and all poor scoring generated an actions plan","5 - Client's satisfaction is performed at regular periods and demonstrating 3 continuous years of improvement","N/A"])
options_list.append(["1 - No return policy is applied","2 - Return policy is defined specifically for each claims","3 - Return policy is defined & provided to client's when requested","4 - Return policy is available on company website with communication line(s)","5 - Return policy is available on company website with communication line(s) with external mediators in case of severe disputes","N/A"])
options_list.append(["1 - After sales services is not evaluated","2 - After sales services is  measured through KPI when requested","3 - After sales services is regularly measured through KPI","4 - After sales services is measured through KPI communicated on company website","5 - After sales services is measured through KPI communicated on company website and demonstrating 3 continuous years of improvement","N/A"])
options_list.append(["1 - Company doesn't communicate to client's on their data management","2 - Company communicates to client's on their data management and disclose them to 3 parties","3 - Company commits to not disclose any client's data even if allowed by legislation","4 - Company applied for all clients most restricted legislations in place (e.g. GDPR versus US patriot act)","5 - Company applied for all clients most restricted legislations in place (e.g. GDPR versus US patriot act) and mandate 3rd party to assess / stress check data protection","N/A"])
options_list.append(["1 - No training done","2 - Training done only for some employees","3 - All employees trained during their on boarding period","4 - Systematic trainings every 3 years to update all sales team","5 - Training done for each changes of the reglementations or internal procedures","N/A"])
options_list.append(["1 - The company is not involved with the communities of its locality.","2 - The company has participated to some donations and charity actions.","3 - The company encourages its employees to support local life with the help of the company.","4 - The company has a clear policy and budget to contribute to the development of local communities.","5 - The company has a clear policy and budget to contribute to the development of local communities, and there are improvements in their results for the last three years.","N/A"])
options_list.append(["1 - No budget dedicaded.","2 - Variable budget issued from government subsidies or external donations.","3 - company's dedicated budget.","4 - Each year a significant budget is disposed in collaboration with key actors in the supply chain.","5 - Improvements in the dedicated budget for the last three years.","N/A"])
options_list.append(["1 - No formal relationship between the company and the local employment partners.","2 - The company has a formal relation with the local partnerts of employment.","3 - The company has formal and trusty relations with the local partnerts of employment and formation.","4 - The company collaborates with the local partnerts of employment and formation to define stratategies for improving the employment rate.","5 - The company collaborates with the local partnerts of employment and formation  to define stratategies for improving the employment rate, and there are improvements in their results for the last three years.","N/A"])
options_list.append(["1 - The public health and safety policy of the company is limited to the mandatory / legal requirements.","2 - The company has a protocol adressing in a generic way the health and safety risks of its activities on local populations. In case of incidents, there is a procedure which is known by some employees.","3 - The company has a protocol specifying a typology of health and safety risks of its activities on local populations. In case of incidents, there is a formal standardised procedure known by all the employees.","3 - The company has a protocol specifying a typology of health and safety risks of its activities on local populations. In case of incidents, there is a formal standardised procedure known by all the employees.","5 - The targets concerning the management of health and safety risks on local poluations are visible and displayed throughout the company, and there are improvements in the target for the last three years.","N/A"])
options_list.append(["1 - The company is not aware about  the risks of its activity on local populations. No procedure exists in case of incidents.","2 - The company has identified global risk categories of its activities on local populations. In case of incidents, there is a procedure which is known by some employees.","3 - The company quantifies and controls the risks of its activities on local populations. In case of incidents, there is a formal standardised procedure known by all the employees.","4 - The company has defined a target and an action plan to prevent and manage the risks according to their nature and gravity. There is a formal standardised procedure known by all the employees and shared with the local populations.","5 - The targets concerning the management of the risks on local poluations are visible and displayed throughout the company, and there are improvements in the target for the last three years.","N/A"])
options_list.append(["1 - No training done.","2 - Training done only for some employees.","3 - All employees trained during their on boarding period.","4 - Periodic training is done to update all the employees.","5 - Training done for each changes of the reglementations or internal procedures.","N/A"])

radio_list = [ "" for i in range(56)]
note = [ 0 for i in range(56)]

scores = [0 for i in range(8)]
target_scores = [3 for i in range(8)]
total_qs = [1,6,2,14,10,8,9,6]
answered_qs = [0 for i in range(8)]
na_qs = [0 for i in range(8)]
answered_per = [0 for i in range(8)]


tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8 , tab9= st.tabs(["Prerequisites","Governance","Human Rights","Labour","Environment",
                                                           "Loyalty of practices","Consummer protection","Local development","Global Overview"])

with tab1:
    radio_list[0] = st.radio(label = qs[0], options = options_list[0])
    note[0] = options_list[0].index(radio_list[0])+1
    if note[0] < 6:
       answered_qs[0] = 1 
       na_qs[0] = 0
       scores[0] = note[0]
    else:
        answered_qs[0] = 0
        na_qs[0] = 1
        scores[0] = 0

with tab2:
    for i in range(1,7):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    
    answered_qs[1] = len([note[i] for i in range(1,7) if note[i] < 6])
    na_qs[1] = 6 - answered_qs[1]
    if len([note[i] for i in range(1,7) if note[i] < 6])==0:
        scores[1] = 0
    else:
        scores[1] = np.mean([note[i] for i in range(1,7) if note[i] < 6])

        
with tab3:
    for i in range(7,9):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    answered_qs[2] = len([note[i] for i in range(7,9) if note[i] < 6])
    na_qs[2] = 2 - answered_qs[2]

    if len([note[i] for i in range(7,9) if note[i] < 6])==0:
        scores[2] = 0
    else:
        scores[2] = np.mean([note[i] for i in range(7,9) if note[i] < 6])

with tab4:
    for i in range(9,23):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    answered_qs[3] = len([note[i] for i in range(9,23) if note[i] < 6])
    na_qs[3] = 14 - answered_qs[3]

    if len([note[i] for i in range(9,23) if note[i] < 6])==0:
        scores[3] = 0
    else:
        scores[3] = np.mean([note[i] for i in range(9,23) if note[i] < 6])

with tab5:
    for i in range(23,33):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    answered_qs[4] = len([note[i] for i in range(23,33) if note[i] < 6])
    na_qs[4] = 10 - answered_qs[4]

    if len([note[i] for i in range(23,33) if note[i] < 6])==0:
        scores[4] = 0
    else:
        scores[4] = np.mean([note[i] for i in range(23,33) if note[i] < 6])

with tab6:
    for i in range(33,41):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    answered_qs[5] = len([note[i] for i in range(33,41) if note[i] < 6])
    na_qs[5] = 8 - answered_qs[5]

    if len([note[i] for i in range(33,41) if note[i] < 6])==0:
        scores[5] = 0
    else:
        scores[5] = np.mean([note[i] for i in range(33,41) if note[i] < 6])

with tab7:
    for i in range(41,50):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    answered_qs[6] = len([note[i] for i in range(41,50) if note[i] < 6])
    na_qs[6] = 9 - answered_qs[6]

    if len([note[i] for i in range(41,50) if note[i] < 6])==0:
        scores[6] = 0
    else:
        scores[6] = np.mean([note[i] for i in range(41,50) if note[i] < 6])

with tab8:
    for i in range(50,56):
        radio_list[i] = st.radio(label = qs[i], options = options_list[i])
        note[i] = options_list[i].index(radio_list[i])+1
    answered_qs[7] = len([note[i] for i in range(50,56) if note[i] < 6])
    na_qs[7] = 6 - answered_qs[7]


    if len([note[i] for i in range(50,56) if note[i] < 6])==0:
        scores[7] = 0
    else:
        scores[7] = np.mean([note[i] for i in range(50,56) if note[i] < 6])
   

print(answered_qs)
print(scores)

def radar_chart(dataf, width, height):  

    fig = px.line_polar(dataf,r='note', theta='theta',line_close=True,range_r=[0,5],width=width, height=height)
   #  st.write(fig)
    st.plotly_chart(fig, use_container_width=False)

with tab9:
    st.header("Global Overview")
    # scores = [0 for i in range(8)]
    # scores[0] = note[0]
    # scores[0] = np.mean(note[1:7])
    # scores[1] = np.mean(note[7:9])
    # scores[2] = np.mean(note[9:23])
    # scores[3] = np.mean(note[23:33])
    # scores[4] = np.mean(note[33:41])
    # scores[5] = np.mean(note[41:50])
    # scores[6] = np.mean(note[50:56])

    c1, c2 = st.columns(2)
    with c1:
        list_Dimension = ["1 - Prerequisites","2 - Governance","3 - Human Rights","4 - Labour","5 - Environment","6 - Loyalty of practices","7 - Consummer protection","8 - Local development"]
        df = pd.DataFrame({"Chapter":list_Dimension,"Total Questions":total_qs,"Answered Questions":answered_qs,"N/A Questions":na_qs,"Actual Score":scores,"Target Score":target_scores})
        st.dataframe(df) 

        SCORING_CRITERIA = np.mean(scores)
        st.info("SCORING CRITERIA: "+str(SCORING_CRITERIA)[:3])
        st.info("Total Questions: "+str(np.sum(total_qs)))
        st.info("Answered Questions: "+str(np.sum(answered_qs)))

    with c2:
        df = pd.DataFrame({"note":scores,"theta":list_Dimension})
        radar_chart(df,width=None, height=None)

       