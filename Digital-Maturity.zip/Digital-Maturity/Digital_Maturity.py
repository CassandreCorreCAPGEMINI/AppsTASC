#!/usr/bin/env python
# -*- encoding: utf-8 -*-


# here put the import lib


import streamlit as st
import random
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import gspread

import os
import sys

# from reportlab.platypus import SimpleDocTemplate, Paragraph, Image, Table, TableStyle
# from reportlab.lib import colors
# from reportlab.lib.styles import getSampleStyleSheet



st.set_page_config(page_title="TASC Welcome page",page_icon="random",layout="wide")

df = pd.DataFrame(
    np.random.randn(10, 5),
    columns=("col %d" % i for i in range(5)))

list_Dimension = ["Technologies","Expérience utilisateur","Organisation"]

list_category = ["Collecte des données", "Analyse de données", "Management des Processus", "Échange de données"]

list_category1 = ["Personnalisation", "Conduite du changement", "Ergonomie"]

list_category2 = ["Standardisation des processus", "Gestion de compétences", "Strategie de choix et implementations des nouvelles technologies", "Culture entreprise"]

@st.cache
def get_data():

   gc = gspread.service_account(filename='hidden-casing-267814-56da527ac3ef.json')

   sh = gc.open_by_key('1X9nH1lqiE1g-4Ck7RSWMVOoNMt4dRDbOhPtW18ivG3U')
   worksheet= sh.get_worksheet(1)
   ques = worksheet.col_values(4)[1:]
   # print(worksheet.row_values(2)[4:9])
   num_ques = len(ques)
   ans = list()
   for i in range(num_ques):
      # print(i)
      ans.append(worksheet.row_values(i+2)[4:9])
      #  print(ans[i])
   print("Length of question:",len(ques))

   worksheet1= sh.get_worksheet(2)
   AHP_ques = worksheet1.col_values(4)[1:]
   num_AHPques = len(AHP_ques)
   AHP_ans = list()
   for j in range(num_AHPques):
      # print(i)
      AHP_ans.append(worksheet1.row_values(j+2)[4:13])
      #  print(ans[i])
   print("Length of question:",len(AHP_ques))

   return ques, ans, AHP_ques, AHP_ans

qs, ans , AHP_ques, AHP_ans= get_data()

def radar_chart(dataf, width, height):  

    fig = px.line_polar(dataf,r='note', theta='theta',line_close=True,range_r=[0,5],width=width, height=height)
   #  st.write(fig)
    st.plotly_chart(fig, use_container_width=False)

# st.write(qs)

st.image("TASC-orange-horizontal-logo.png",width=500)

st.header("Évaluation de la maturité digitale")
e1 = st.text_input('Nom de l\'entreprise')
e2 = st.text_input('Adresse mail')
e3 = st.text_input('Rôle du participant')
e4 = st.text_input('Taille de l\'entreprise')
e5 = st.text_input('Secteur d\'activité')
e = e1+e2+e3+e4+e5
tab1, tab2, tab3, tab4, tab5 = st.tabs(["Technologies","Expérience utilisateur","Organisation","Pondération","Résultats"])
if 'num' not in st.session_state:
    st.session_state.num = 0
choices = [ "" for i in range(len(qs))]
comments = [ "" for i in range(len(qs))]
note = [ 0 for i in range(len(qs))]
note_mean = [0 for i in range(11)]
note_pond = [0 for i in range(11)]
weight = [1 for i in range(14)]
print(len(choices))
i=0

with tab4:
   st.info("Détermination des poids des sous-critères")
   t1, t2, t3, t4 = st.tabs(["Technologies","Expérience utilisateur","Organisation", "Maturité Digitale"])
   AHP = [ "" for i in range(len(AHP_ques))]
   note_list = [1/9, 1/7, 1/5, 1/3, 1, 3, 5 , 7, 9]
   note_AHP = [ 0 for i in range(len(AHP_ques))]
   c = [ "" for i in range(len(AHP_ques))]
   with t1:
      st.write("Dans votre entreprise/service, au vu d\'améliorer votre utilisation des technologies, ")
      x1 = np.ones((4, 4), dtype=float)
      row,col = np.diag_indices_from(x1)
      x1[row, col] = 1
      for i in range(6):
         AHP[i] = st.selectbox(label = AHP_ques[i][85:], options = AHP_ans[i], index=4)
         # print(note_list[i])
         note_AHP[i] =note_list[AHP_ans[i].index(AHP[i])]    
      c[1] = st.text_input(label="Commentaire", key="pond1")

      x1[0,1] = note_AHP[0]
      x1[0,2] = note_AHP[1]
      x1[0,3] = note_AHP[2]
      x1[1,2] = note_AHP[3]
      x1[1,3] = note_AHP[4]
      x1[2,3] = note_AHP[5]
      x1[1,0] = 1/x1[0,1]
      x1[2,0] = 1/x1[0,2]
      x1[3,0] = 1/x1[0,3] 
      x1[2,1] = 1/x1[1,2]
      x1[3,1] = 1/x1[1,3]
      x1[3,2] = 1/x1[2,3]
      print(x1)
      print(x1.sum(axis=0))
      x11 = x1 / x1.sum(axis=0)
      print(x11)
      print(x11.mean(axis=1))

   with t2:
      st.write("Dans votre entreprise/service, au vu d\'améliorer l\'expérience des utilisateurs par rapport aux des nouvelles technologies implémentées, ")
      x2 = np.ones((3, 3), dtype=float)
      row,col = np.diag_indices_from(x2)
      x2[row, col] = 1
      for i in range(6,9):
         AHP[i] = st.selectbox(label = AHP_ques[i][135:], options = AHP_ans[i], index=4)
         note_AHP[i] =note_list[AHP_ans[i].index(AHP[i])]
      c[2] = st.text_input(label="Commentaire", key="pond2")

      x2[0,1] = note_AHP[6]
      x2[0,2] = note_AHP[7]
      x2[1,2] = note_AHP[8]
      x2[1,0] = 1/x2[0,1] 
      x2[2,0] = 1/x2[0,2]
      x2[2,1] = 1/x2[1,2]
      print(x2)
      print(x2.sum(axis=0))
      x22 = x2 / x2.sum(axis=0)
      print(x22)
      print(x22.mean(axis=1))

   with t3:
      st.write("Dans votre entreprise, au vu de préparer votre structure organisationnelle pour accueillir des nouvelles technologies, ")
      x3 = np.ones((4, 4), dtype=float)
      row,col = np.diag_indices_from(x3)
      x3[row, col] = 1
      for i in range(9,15):
         AHP[i] = st.selectbox(label = AHP_ques[i][119:], options = AHP_ans[i], index=4)
         note_AHP[i] =note_list[AHP_ans[i].index(AHP[i])]
      c[3] = st.text_input(label="Commentaire", key="pond3")

      x3[0,1] = note_AHP[9]
      x3[0,2] = note_AHP[10]
      x3[0,3] = note_AHP[11]
      x3[1,2] = note_AHP[12]
      x3[1,3] = note_AHP[13]
      x3[2,3] = note_AHP[14]
      x3[1,0] = 1/x3[0,1]
      x3[2,0] = 1/x3[0,2]
      x3[3,0] = 1/x3[0,3] 
      x3[2,1] = 1/x3[1,2]
      x3[3,1] = 1/x3[1,3]
      x3[3,2] = 1/x3[2,3]
      x33 = x3 / x3.sum(axis=0)
      print(x33)
      print(x33.mean(axis=1))

   with t4:
      with st.form("form_pond"):

         st.write("Au vu de préparer votre entreprise pour la transformation digitale, ")
         x4 = np.ones((3, 3), dtype=float)
         row,col = np.diag_indices_from(x4)
         x4[row, col] = 1
         for i in range(15,18):
            AHP[i] = st.selectbox(label = AHP_ques[i][67:], options = AHP_ans[i], index=4)
            note_AHP[i] =note_list[AHP_ans[i].index(AHP[i])]
         c[4] = st.text_input(label="Commentaire", key="pond4")

         x4[0,1] = note_AHP[15]
         x2[0,2] = note_AHP[16]
         x4[1,2] = note_AHP[17]
         x4[1,0] = 1/x4[0,1]
         x4[2,0] = 1/x4[0,2]
         x4[2,1] = 1/x4[1,2]
         print(x4)
         print(x4.sum(axis=0))
         x44 = x4 / x4.sum(axis=0)
         print(x44)
         print(x44.mean(axis=1))
         print(x44.mean(axis=1)[0])

         weight = np.concatenate((x11.mean(axis=1),x22.mean(axis=1),x33.mean(axis=1),x44.mean(axis=1)), axis = 0)
         print("weight:",weight)

         sub_pond= st.form_submit_button("Soumettre")
         if sub_pond:  
            cof_df = pd.DataFrame({"Dimension":list_Dimension,"Coefficient":weight[11:14]})
            st.dataframe(cof_df) 

   # weight = np.concatenate((x11.mean(axis=1),x22.mean(axis=1),x33.mean(axis=1),x44.mean(axis=1)), axis = 0)
   # print("weight:",weight)

i=0

with tab1:
   with st.form("my_form1"):
      
      st.header("Collecte des données")
      
      num = st.session_state.num
      for _, _ in zip(qs[0:5], ans[0:5]): 
         choices[i] = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[0] = np.mean(note[0:5])
         note_pond[0] = note_mean[0]*weight[0]
         i+=1

      st.header("Analyse de données")
      for _, _ in zip(qs[5:9], ans[5:9]): 
         choices[i]  = st.radio(qs[i], options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[1] = np.mean(note[5:9])
         note_pond[1] = note_mean[1]*weight[1]
         i+=1

      st.header("Management des Processus")
      for _, _ in zip(qs[9:15], ans[9:15]): 
         choices[i]  = st.radio(qs[i], options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[2] = np.mean(note[9:15])
         note_pond[2] = note_mean[2]*weight[2]
         i+=1


      st.header("Data exchange")
      for _, _ in zip(qs[15:19], ans[15:19]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[3] = np.mean(note[15:19])
         note_pond[3] = note_mean[3]*weight[3]
         i+=1
      
      submitted1 = st.form_submit_button("Soumettre")
      if submitted1:
            df1 = pd.DataFrame({"note":note_mean[0:4],"theta":list_category})
            radar_chart(df1,width=None, height=None)
print(choices)
print(note)
   

with tab2:
   with st.form("my_form2"):
      st.header("Personnalisation")
      for _, _ in zip(qs[19:21], ans[19:21]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[4] = np.mean(note[19:21])
         note_pond[4] = note_mean[4]*weight[4]
         i+=1
      
      i+=1

      st.header("Conduite du changement")
      for _, _ in zip(qs[22:26], ans[22:26]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[5] = np.mean(note[22:26])
         note_pond[5] = note_mean[5]*weight[5]
         i+=1

      st.header("Ergonomie")
      for _, _ in zip(qs[26:30], ans[26:30]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[6] = np.mean(note[26:30])
         note_pond[6] = note_mean[6]*weight[6]
         i+=1

      submitted2 = st.form_submit_button("Soumettre")
      if submitted2:
            df = pd.DataFrame({"note":note_mean[4:7],"theta":list_category1})
            radar_chart(df,width=None, height=None)

with tab3:
   
   with st.form("my_form3"):

      st.header("Standardisation des processus")
      for _, _ in zip(qs[30:33], ans[30:33]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[7] = np.mean(note[30:33])
         note_pond[7] = note_mean[7]*weight[7]
         i+=1

      i+=2

      st.header("Gestion de compétences")
      for _, _ in zip(qs[35:38], ans[35:38]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[8] = np.mean(note[35:38])
         note_pond[8] = note_mean[8]*weight[8]
         i+=1

      st.header("strategie de choix et implementations des nouvelles technologies")
      for _, _ in zip(qs[38:41], ans[38:41]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         comments[i] = st.text_input(label="Commentaire", key=str(i+1))
         note[i] = ans[i].index(choices[i])+1
         note_mean[9] = np.mean(note[38:41])
         note_pond[9] = note_mean[9]*weight[9]
         i+=1

      st.header("Culture entreprise ")
      for _, _ in zip(qs[41:45], ans[41:45]): 
         choices[i]  = st.radio(qs[i],options=ans[i])
         note[i] = ans[i].index(choices[i])+1
         note_mean[10] = np.mean(note[41:45])
         note_pond[10] = note_mean[10]*weight[10]
         i+=1
      
      submitted3 = st.form_submit_button("Soumettre")
      if submitted3:
            df = pd.DataFrame({"note":note_mean[7:11],"theta":list_category2})
            radar_chart(df,width=None, height=None)
   


with tab5:

   scores = [0 for i in range(3)]
   scores[0] = np.sum(note_pond[0:4])
   scores[1] = np.sum(note_pond[4:7])
   scores[2] = np.sum(note_pond[7:11])
   maturity_note = scores[0]*weight[11]+scores[1]*weight[12]+scores[2]*weight[13]


   st.header("Résultat global")
   with st.form("form1"):

      c1, c2 = st.columns(2)
      with c1:
         st.info("Niveau de maturité: "+str(maturity_note)[:3])
         # st.write('''maturity_score = scores[Technologies]*coef[Technologies]+scores[User Experience]*coef[User Experience]+scores[Organisation]*coef[Organisation]''')
         # st.write(maturity_note)
         st.write("Coefficient par dimension")
         
         cof_df = pd.DataFrame({"Dimension":list_Dimension,"Coefficient":weight[11:14]})
         st.dataframe(cof_df) 
       
      with c2:
         st.warning("Interprétation")
         if maturity_note < 3:
            st.write("Faible. En début de réflexion ou seulement quelques initiatives sont prises au regard de la transformation digitale.")
         elif maturity_note >= 3 and maturity_note<4:
            st.write("Intermédiaire. L’entreprise est dans le niveau standard de maturité digitale par rapport à son secteur d'activité.")
         elif maturity_note>=4 and maturity_note <5:
            st.write("Bon. Des améliorations sont possibles à faire mais le niveau de maturité digitale est supérieur à la moyenne des entreprises du secteur.")
         else:
            st.write("Excellent. Leader en digitalisation. Démarche d'amélioration continue et d'innovation, en avance par rapport au secteur industriel.")
      
      sub1 = st.form_submit_button("Actualiser")

   st.header("Évaluation de la maturité par dimension")
   with st.form("form2"):

      c_1, c_2 = st.columns(2)
      with c_1:
         st.write("Scores par dimension")
         df1=pd.DataFrame({"Dimension":list_Dimension,"Score":scores})
         st.dataframe(df1)

         df = pd.DataFrame({"note":scores,"theta":list_Dimension})
         radar_chart(df,width=None, height=None)
         
      with c_2:
         st.warning("Profil")
         if scores[0]>=4 and scores[1] >= 4 and scores[2] >=4:
            st.write("Mature")
         elif scores[0]>=3  and scores[1] < 3 and scores[2]>=3:
            st.write("Robust")
         elif scores[0]>=3 and scores[1] >= 3 and scores[2]<3:
            st.write("Efficient")
         elif scores[0]>=2 and  scores[0]<4 and scores[1]>=3 and scores[2]>=3:
            st.write("Ready")
         else:
            st.write("Immature")
         
         st.warning("Modèle théorique de maturité digitale")
         st.image("profils.jpg",width=400)

      sub2 = st.form_submit_button("Actualiser")

   st.header("Technologies")
   with st.form("form3"):
      col1, col2 = st.columns(2)
      with col1:
         st.info("Technologies: "+str(scores[0])[:3])
         df1=pd.DataFrame({"Technologies":list_category,"Score":note_mean[0:4]})
         st.dataframe(df1) 
         df = pd.DataFrame({"note":note_mean[0:4],"theta":list_category})
         radar_chart(df,width=400, height=400)
        
      with col2:
         st.warning("Interprétation")
         if scores[0]>=4:
            st.write('''D’un point de vue technologique, la gestion de l’intégralité ou de la majorité de vos données et de vos processus est automatisée dans votre système d'information (SI). Enfin, vous assurez une bonne qualité des flux de vos données via l’interfaçage des outils à l’intérieur de SI.''')
         elif scores[0]>=3 and scores[0]<4:
            st.write('''D’un point vue technologique vous êtes au niveau nominal : votre ERP collecte automatiquement les données, vous avez une sauvegarde de celles-ci et vous les analysez, principalement de façon manuelle. Vous avez mis en place un partage des données effectif entre les principaux services.
 Cependant, votre ERP d’entreprise n’est pas utilisé de façon optimale. Les données collectées par ce dernier peuvent être incomplètes dans certains cas et demandent une vérification. Votre processus de partage et d’interconnexion devrait être étendu à l’ensemble des services de l’entreprise.
 ''')
         elif scores[0]<3:
            st.write('''D’un point de vue technologique, l'entreprise n'est pas mature : la plupart des activités et la gestion de données sont effectuées manuellement et/ou avec des outils non adaptés. Par exemple, la collecte des données n’est pas standardisée et elle est faite manuellement. Quelques outils sont présents, mais vous n’avez pas implémenté des systèmes d’information type ERP. Enfin, la sauvegarde des données est peu fiable (ex. mail, serveur dédié non sécurisé …).''')

         st.warning("Recommandation")
         if scores[0]>=4:
            st.write('''Préconisations pour exceller en matière de maturité digitale :
  
Maintenez à jour vos IoT et optimisez votre IA afin de capitaliser sur les données en temps réel pour le traitement des anomalies et l’aide à la prise de décision en temps réel. 
Avec votre RPA (Robotic Process Automation), veillez à la cohérence permanente entre les processus automatisés dans le système d’information (SI) et les processus métiers. 
Renforcez le système de sécurisation des données. 
Favorisez le partage et la communication des résultats interservices au travers du SI.
''')
         elif scores[0]>=3 and scores[0]<4:
            st.write('''Préconisations pour exceller en matière de maturité digitale :
  
Nous préconisons de renforcer le processus de montée en compétence des nouveaux collaborateurs. En complément, il faudrait accentuer les démarches d’amélioration continue et le développement de projet de R&I et de la veille technologique au sein de votre organisation. 
Également, veillez à adapter en continu votre stratégie informatique pour l’intégration de nouvelles technologies. Enfin, impliquez vos collaborateurs, via une communication dynamique sur l’innovation au sein de votre entreprise. 
''')
         elif scores[0]<3:
            st.write('''Améliorations pour atteindre le niveau nominal de maturité digitale :
  
Afin de parvenir à un niveau de maturité nominal, nous suggérons que votre entreprise déploie un SI de type ERP pour collecter automatiquement les données même si certaines restent collectées manuellement. Envisagez une sauvegarde de vos données sur des serveurs afin d’éviter les pertes de ces dernières. Utiliser un ERP vous permettrait une communication efficace entre les principaux services ainsi que le partage des données de manière standardisée et sécurisée.
En outre, afin de pouvoir connaitre l’état de santé de votre production, initiez le développement d’analyse de vos données.
''') 

      sub3 = st.form_submit_button("Actualiser")
      
   st.header("Expérience utilisateur")
   with st.form("form4"): 
      col3, col4 = st.columns(2)
      with col3:
         st.info("Expérience utilisateur: "+str(scores[1])[:3])
         df1=pd.DataFrame({"Expérience utilisateur":list_category1,"Score":note_mean[4:7]})
         st.dataframe(df1) 
         df = pd.DataFrame({"note":note_mean[4:7],"theta":list_category1})
         radar_chart(df,width=400, height=400)
         
      with col4:
         st.warning("Interprétation")
         if scores[1]>=4:
            st.write('''Concernant le facteur humain, nous estimons que vous intégrez convenablement vos collaborateurs, tant au niveau du déploiement de nouvelles technologies qu'au niveau de la personnalisation des systèmes d'information. Vous prenez en compte leurs besoins métiers, ainsi que des facteurs ergonomiques. Ainsi, nous estimons que vous assurez un bon niveau de flexibilité et d'efficacité de vos employés.''')
         elif scores[1]>=3 and scores[1]<4:
            st.write('''Concernant le facteur humain, vous êtes au niveau nominal: vous avez commencé à déployer une stratégie d’implication des utilisateurs lors des changement technologiques. Ceci a pour objectif de leur permettre de participer à la définition des interfaces et du choix d’outils en cohérence avec les processus métier. Cependant, votre conduite du changement reste assez fragile, l’implication des utilisateurs n’arrive qu’aux étapes finales du processus de transformation digitale. Sur la partie ergonomie du SI, il persiste l’utilisation de quelques outils externes qui cohabitent avec l’ERP du fait de la complexité de certaines fonctionnalités. Ce qui entraine une validation manuelle de certaines données, dans le SI. Sur l’aspect personnalisation du SI, seuls les métiers principaux sont consultés via des UAT (User Acceptance Test).''')
         elif scores[1]<3:
            st.write('''D’un point de vue facteur humain, votre entreprise ne s’interroge pas suffisamment sur les besoins métiers. Nous avons identifié que les interfaces des outils existants ne sont que peu ou pas personnalisées pour l’utilisateur. Il apparait aussi que lors de changement, les utilisateurs ne sont pas impliqués et qu’ils doivent s’adapter aux nouveaux outils. L’ergonomie et l’automatisation de votre système d’information n’est pas une priorité.''')
         
         st.warning("Recommandation")
         if scores[1]>=4:
            st.write('''Préconisations pour exceller en matière de maturité digitale :
  
Veillez à l’implication de vos collaborateurs dans le cadre d’une démarche d’amélioration continue de leur environnement de travail et expérience utilisateur au regard des outils existants. Valorisez et motivez toutes les propositions d’amélioration des interfaces métier.''')
         elif scores[1]>=3 and scores[1]<4:
            st.write(''' Préconisations pour évolution de la maturité digitale :
  
Nous préconisons, pour les aspects de conduite du changement et de personnalisation, de mettre en place des UAT avec les key users et les utilisateurs afin d’identifier les besoins spécifiques des métiers centraux et des métiers de support. 
Concernant l’ergonomie, la mise en place de l’automatisation partielle du SI est nécessaire. Il faut aussi envisager la construction d’outils pour supporter la prise de décision.

''')
         elif scores[1]<3:
            st.write('''Améliorations pour atteindre le niveau nominal de maturité digitale :
  
Afin de parvenir à un niveau de maturité nominal, nous suggérons que votre entreprise déploie un SI de type ERP pour collecter automatiquement les données même si certaines restent collectées manuellement. Envisagez une sauvegarde de vos données sur des serveurs afin d’éviter les pertes de ces dernières. Utiliser un ERP vous permettrait une communication efficace entre les principaux services ainsi que le partage des données de manière standardisée et sécurisée.
En outre, afin de pouvoir connaitre l’état de santé de votre production, initiez le développement d’analyse de vos données.
''')
      
      sub4 = st.form_submit_button("Actualiser")
  
   st.header("Organisation")
   with st.form("form5"): 
      col5, col6 = st.columns(2)
      with col5:
         st.info("Organisation: "+str(scores[2])[:3])
         df1=pd.DataFrame({"Organisation":list_category2,"Score":note_mean[7:11]})
         st.dataframe(df1) 
         df = pd.DataFrame({"note":note_mean[7:11],"theta":list_category2})
         radar_chart(df,width=400, height=400)
   
      with col6:
         st.warning("Interprétation")
         if scores[2]>=4:
            st.write('''Votre infrastructure organisationnelle est robuste. D'une part, vous avez une stratégie définie en interne pour l'intégration des nouvelles technologies, que nous pouvons qualifier de collaborative. D'autre part, vous veillez à la formation et à la montée en compétence de vos collaborateurs afin de garantir un niveau d'expertise conforme à votre niveau de maturité digitale. Aussi, vous disposez en interne d'une veille technologique et de services de recherche et développement, voire d'innovation, qui vous permettent d'être à la pointe des nouvelles technologies et ainsi de protéger votre position concurrentielle sur le marché.''')
         elif scores[2]>=3 and scores[2]<4:
            st.write('''Votre entreprise est au niveau nominal sur l’aspect organisationnel : vous avez mis en place une veille technologique qui permet à la direction de prendre des décisions sur les évolutions à considérer en termes de transformation digitale. Également, vos processus sont standardisés pour une partie des métiers. Vous avez mis en place une stratégie pour renforcer vos compétences internes en matière de digitalisation.
 Cependant, la direction n’implique pas assez les utilisateurs dans le processus de prise de décision sur les aspects d’innovation technologique interne. L’ouverture sur la veille technologique est insuffisante, ce qui entraine une stratégie de court terme sur les besoins en recrutement de compétences IT. La standardisation et digitalisation de vos processus est accomplie, mais il reste une certaine difficulté sur le partage et la connaissance de ces derniers à l’ensemble de l’entreprise.
 ''')
         elif scores[2]<3:
            st.write('''D’un point de vue organisationnel, nous avons identifié que la standardisation et la mise à jour de vos processus sont peu ou pas effectuées. Il manque aussi une revue de ces processus permettant d’identifier des opportunités d’amélioration technologique. De plus, votre entreprise n’assure pas convenablement le maintien de compétences technologiques solides, que ce soit en interne ou en externe. En outre, la stratégie de choix et d’implémentation des nouvelles technologies n’intègre pas forcément les utilisateurs dans les processus décisionnels et de déploiement. Enfin, concernant la culture d’entreprise, des actions d’amélioration comme une veille technologique et des forums dédiés à l’innovation sont nécessaires pour encourager l’esprit innovant de vos collaborateurs.''')
         
         st.warning("Recommandation")
         if scores[2]>=4:
            st.write('''Préconisations pour exceller en matière de maturité digitale :
  
Nous préconisons de renforcer le processus de montée en compétence des nouveaux collaborateurs. En complément, il faudrait accentuer les démarches d’amélioration continue et le développement de projet de R&I et de la veille technologique au sein de votre organisation. 
Également, veillez à adapter en continu votre stratégie informatique pour l’intégration de nouvelles technologies. Enfin, impliquez vos collaborateurs, via une communication dynamique sur l’innovation au sein de votre entreprise.
''')
         elif scores[2]>=3 and scores[2]<4:
            st.write('''Préconisations pour évolution de la maturité digitale :
  
 Nous préconisons la création de communautés de référents métier afin de travailler à l’amélioration des processus de l’entreprise et de mettre en place une communication à destination de tous.
 Sur les aspects formation et recrutement, il faut anticiper plus fortement les besoins afin d’assurer un niveau de compétence élevé de vos collaborateurs. Vous devez concevoir l’innovation comme un axe important de votre entreprise et donc bien structurer votre service R&D afin qu’il vous apporte des avancées technologiques utiles au maintien de votre compétitivité.
 ''')
         elif scores[2]<3:
            st.write('''Améliorations pour atteindre le niveau nominal de maturité digitale :
  
 Afin de parvenir à un niveau de maturité nominal, il faudrait passer à un système de standardisation de vos processus pour les métiers principaux. Ensuite, afin de renforcer vos compétences internes nous vous proposons de mettre en place une stratégie de recrutement IT et de formation de vos collaborateurs. Enfin, nous suggérons que votre entreprise mette en place une veille technologique permettant à la direction de prendre des décisions sur les évolutions IT à développer.
 ''')
         
      sub5 = st.form_submit_button("Actualiser")
   
   

   gc = gspread.service_account(filename='hidden-casing-267814-56da527ac3ef.json')
   sh = gc.open_by_key('1X9nH1lqiE1g-4Ck7RSWMVOoNMt4dRDbOhPtW18ivG3U')
   worksheet= sh.get_worksheet(1)
   # range_value = 'O2:O46'
   # cell_list = worksheet.range(range_value)
   
   cell_list = worksheet.range(2,17,46,17)
   k = 0
   for cell in cell_list:
        cell.value = note[k]
        k+=1
   worksheet.update_cells(cell_list)
   submitted4 = st.button("Générer un rapport")
   if submitted4:
     pass

if __name__ == '__main__':
   print("Maturity Digital")