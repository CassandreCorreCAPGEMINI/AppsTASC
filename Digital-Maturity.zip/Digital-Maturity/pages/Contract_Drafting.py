#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   contract.py
@Time    :   2024/05/20 09:33:53
@Author  :   Xin HUANG 
@Version :   1.0
@Contact :   xin.huang@capgemini.com
'''

# here put the import lib
import streamlit as st
# from annotated_text import annotated_text, annotation
from streamlit.logger import get_logger
import inspect
import textwrap
import time
import json
import numpy as np
from streamlit.hello.utils import show_code

from google.cloud import aiplatform
import base64
import vertexai
from vertexai import preview
from vertexai.generative_models import GenerativeModel, Part, FinishReason
import vertexai.preview.generative_models as generative_models
from google.oauth2 import service_account

def header_app():
    
    st.image("TASC-orange-horizontal-logo.png",width=500,)
    with st.expander("ℹ️ - About this app", expanded=True):

        st.write(
        """     
-   The *Contract drafting* app is used to quickly generate corresponding contracts or terms according to needs.
-   Our app is based on the model Gemini 1.5 from Google Vertex AI. 
	    """
    ) 
header_app()


credentials = service_account.Credentials.from_service_account_file('tasc-423506-9ea19c31fd3d.json')

# from google.cloud import language_v1

        
generation_config = {
    "max_output_tokens": 8192,
    "temperature": 0.2,
    "top_p": 0.8,
}

safety_settings = {
    generative_models.HarmCategory.HARM_CATEGORY_HATE_SPEECH: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    generative_models.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    generative_models.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    generative_models.HarmCategory.HARM_CATEGORY_HARASSMENT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
}

def generate():
  vertexai.init(project="tasc-423506", location="europe-west9",credentials=credentials)
  model = GenerativeModel(
    "gemini-1.5-flash-001",
  )
  responses = model.generate_content(
      [text1],
      generation_config=generation_config,
      safety_settings=safety_settings,
      stream=True,
  )
  res_list = list()
  for response in responses:
    print(response.text, end="")
    res_list.append(response.text)
  return res_list
       
st.header('Contract drafting', divider='rainbow')
option_contract = st.selectbox(
   "Contract requirements:",
   ("Write a procurement contract for Company BBB to purchase network equipment from the AAA company.", 
    "Write a procurement contract",
    "Write a procurement contract for Company BBB to purchase network equipment from the AAA company. The contract needs to contain a Renewal Term  clause, and all disputes will be subject to the jurisdiction of the EU."),
   index=0,
   placeholder="Select contract ...",
)

contract_req = st.text_area(
     "Contract requirements:",
    option_contract
    ) 
st.warning("The more detailed the contract requirements are, the higher the quality of the generated contract will be.")
text1 = contract_req



if st.button(label="✨ Submit", key = 2):
    res1 = generate()
    show_res1 = "".join(res1)
    re1  = st.markdown( show_res1) 


st.header('Clause drafting', divider='rainbow')
option_clause = st.selectbox(
   "Clause requirements:",
   ("Write a contract clause of Renewal Term ","Write a contract clause of insurance","Write a contract clause of Termination for Convenience "),
   index=0,
   placeholder="Select clause ...",
)

clause_req = st.text_area(
     "Clause requirements:",
    option_clause
    )
st.warning("The more detailed the clause requirements are, the higher the quality of the generated clause will be.") 
text1 = clause_req



if st.button(label="✨ Submit", key = 3):
    res2 = generate()
    show_res2 = "".join(res2)
    re1  = st.markdown( show_res2) 

