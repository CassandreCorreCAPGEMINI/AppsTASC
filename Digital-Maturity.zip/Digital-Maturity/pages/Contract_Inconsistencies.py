#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   Contract_extraction.py
@Time    :   2024/07/03 13:56:12
@Author  :   Xin HUANG 
@Version :   1.0
@Contact :   xin.huang@capgemini.com
'''

# here put the import lib

import streamlit as st
# from annotated_text import annotated_text, annotation
from streamlit.logger import get_logger
import inspect
import textwrap
import time
import json
import numpy as np
from streamlit.hello.utils import show_code

from google.cloud import aiplatform
import base64
import vertexai
from vertexai import preview
from vertexai.generative_models import GenerativeModel, Part, FinishReason
import vertexai.preview.generative_models as generative_models
from google.oauth2 import service_account

from pypdf import PdfReader
from pdf2image import convert_from_bytes
import pytesseract
import fitz  # PyMuPDF
from PIL import Image


credentials = service_account.Credentials.from_service_account_file('tasc-423506-9ea19c31fd3d.json')
count = 0

def header_app():
    
    st.image("TASC-orange-horizontal-logo.png",width=500,)
    with st.expander("ℹ️ - About this app", expanded=True):

        st.write(
        """     
-   The *Contract_Inconsistencies* app is used to determine if a contract has inconsistencies that do not comply with pre-specified rules and laws.
-   Our app is based on the model Gemini 1.5 from Google Vertex AI. 
-   Fdf and txt files are accepted by our app, Tick the checkbox OCR for read PDf scanned.
	    """
    )
    st.header("Contract Inconsistencies",divider='rainbow')     
header_app()

def load_file(count):
    """Load text from file"""
    uploaded_file = st.file_uploader("Upload Contract:",type=['pdf', 'txt'], key=count)
    file_name =" "
    raw_text=" "
    if uploaded_file is not None:
        print(uploaded_file.name)
        file_name = uploaded_file.name
        if uploaded_file.type == "text/plain":
            raw_text = str(uploaded_file.read(),"utf-8")
        elif uploaded_file.type == "application/pdf":
            reader = PdfReader(uploaded_file)
            text = ""
            for page in reader.pages:
                text += page.extract_text() + "\n"
            raw_text = text

    return raw_text, file_name

def extract_text_from_pdf(pdf_document):
    text = ""
    for page_num in range(pdf_document.page_count):
        page = pdf_document.load_page(page_num)
        text += page.get_text()
    return text

def load_ocr(count):
    uploaded_file = st.file_uploader("Choose a PDF file", type="pdf", key=count)
    file_name =" "
    raw_text=" "
    if uploaded_file is not None:
        print(uploaded_file.name)
        file_name = uploaded_file.name
        pdf_document = fitz.open(stream=uploaded_file.read(), filetype="pdf")
        # for page_num in range(len(pdf_document)):
        #     page = pdf_document.load_page(page_num)
        # # Convert page to an image
        #     pix = page.get_pixmap()
        #     img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
        # # Use Tesseract to extract text
        #     page_text = pytesseract.image_to_string(img)
        #     raw_text += page_text + "\n"

        extracted_text = extract_text_from_pdf(pdf_document)
        raw_text = extracted_text
    return raw_text, file_name

contract,uploaded = "",""
# raw_text,uploaded = load_file(count)
# if raw_text != None and raw_text != '':
#     with st.expander("See contract text"):
#         st.write(raw_text)

ocr1 = st.checkbox("Enable OCR: for reading pdf scanned on image", key="ocr1") 
if ocr1:
    contract,uploaded = load_ocr(count)
    count += 1
    if contract != None and contract != '':
        with st.expander("See contract text"):
            st.write(contract)
else:
    contract,uploaded = load_file(count)
    count += 1
    if contract != None and contract != '':
        with st.expander("See contract text"):
            st.write(contract)


option_ques = st.selectbox(
   "Rules:",
   ( "A contract cannot be governed by the laws of more than one country","A contract cannot have multiple insurance clauses"),
   index=0,
   placeholder="Select contact method...",
)

question  = st.text_area(
     "Rules selected or Customized rules:",
    option_ques
    ) 


prompt = """Answer the question based on the context below. Extract the exact full sentence that contains the answer. If the question cannot be answered using the information provided answer with “I cannot find the information”"""
results =""

def generate():
  vertexai.init(project="tasc-423506", location="europe-west9",credentials=credentials)
  model = GenerativeModel(
    "gemini-1.5-flash-001",
  )
  responses = model.generate_content(
      [text1],
      generation_config=generation_config,
      safety_settings=safety_settings,
      stream=True,
  )
  res_list = list()
  for response in responses:
    print(response.text, end="")
    res_list.append(response.text)
  return res_list


text1 = contract+"\n Rules: "+question+"Combine the content of the contract with the defined rules to determine whether the contract complies with the rules"

generation_config = {
    "max_output_tokens": 8192,
    "temperature": 0.2,
    "top_p": 0.8,
}

safety_settings = {
    generative_models.HarmCategory.HARM_CATEGORY_HATE_SPEECH: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    generative_models.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    generative_models.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    generative_models.HarmCategory.HARM_CATEGORY_HARASSMENT: generative_models.HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
}



if st.button(label="✨ Submit", key = 1):
    res = generate()
    show_res = "".join(res) 
    re  = st.markdown( show_res) 